-- --------------------------------------------------------
-- Hôte :                        localhost
-- Version du serveur:           5.7.14 - MySQL Community Server (GPL)
-- SE du serveur:                Win64
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Export de la structure de la base pour galleries
CREATE DATABASE IF NOT EXISTS `galleries` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;
USE `galleries`;

-- Export de la structure de la table galleries. accounts
CREATE TABLE IF NOT EXISTS `accounts` (
  `idAccount` int(11) NOT NULL AUTO_INCREMENT,
  `pseudoAccount` varchar(255) COLLATE utf8_bin NOT NULL,
  `mailAccount` varchar(255) COLLATE utf8_bin NOT NULL,
  `passwordAccount` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idAccount`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Export de données de la table galleries.accounts : 0 rows
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;

-- Export de la structure de la table galleries. categories
CREATE TABLE IF NOT EXISTS `categories` (
  `idCategory` int(11) NOT NULL AUTO_INCREMENT,
  `nameCategory` varchar(255) NOT NULL,
  PRIMARY KEY (`idCategory`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Export de données de la table galleries.categories : 6 rows
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`idCategory`, `nameCategory`) VALUES
	(1, 'Utilisateur'),
	(2, 'Basket'),
	(6, 'Manga'),
	(3, 'Films'),
	(7, 'Sports'),
	(8, 'Séries');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Export de la structure de la table galleries. categories_images
CREATE TABLE IF NOT EXISTS `categories_images` (
  `idImage` int(11) NOT NULL,
  `idCategory` int(11) NOT NULL,
  PRIMARY KEY (`idImage`,`idCategory`),
  KEY `idCategorie` (`idCategory`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Export de données de la table galleries.categories_images : 35 rows
/*!40000 ALTER TABLE `categories_images` DISABLE KEYS */;
INSERT INTO `categories_images` (`idImage`, `idCategory`) VALUES
	(1, 2),
	(2, 2),
	(3, 2),
	(4, 3),
	(5, 3),
	(9, 3),
	(10, 3),
	(11, 3),
	(12, 3),
	(13, 3),
	(14, 3),
	(15, 3),
	(16, 3),
	(17, 3),
	(18, 3),
	(19, 3),
	(20, 3),
	(21, 3),
	(22, 3),
	(23, 3),
	(24, 3),
	(25, 3),
	(26, 3),
	(28, 2),
	(28, 6),
	(29, 6),
	(30, 6),
	(31, 6),
	(32, 3),
	(33, 3),
	(34, 3),
	(35, 2),
	(35, 6),
	(36, 8),
	(38, 2);
/*!40000 ALTER TABLE `categories_images` ENABLE KEYS */;

-- Export de la structure de la table galleries. images
CREATE TABLE IF NOT EXISTS `images` (
  `idImage` int(11) NOT NULL AUTO_INCREMENT,
  `urlImage` text NOT NULL,
  `dateImage` date DEFAULT NULL,
  `scoreImage` int(11) DEFAULT '0',
  `descriptionImage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idImage`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

-- Export de données de la table galleries.images : 33 rows
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` (`idImage`, `urlImage`, `dateImage`, `scoreImage`, `descriptionImage`) VALUES
	(2, 'https://excelsiorpallacanestro2014.files.wordpress.com/2015/01/basket1.jpg', NULL, 0, 'Panier !'),
	(3, 'http://www.parierbasket.net/wp-content/imgsuser-basket-nuit-94.jpg', NULL, 4, NULL),
	(4, 'http://img.filmsactu.net/datas/films/b/r/brice-de-nice-3/xl/brice-de-nice-3-photo-577ce33c053d5.jpg', NULL, 2, NULL),
	(5, 'https://pbs.twimg.com/profile_images/435153734159839232/a3RA5UQW.jpeg', NULL, 1, NULL),
	(9, 'http://3.bp.blogspot.com/-6yr4xwcBbhk/T3M9NlH1S9I/AAAAAAAAAV0/enEJOgMrM8U/s1600/jamel-debbouze.jpeg', NULL, 0, NULL),
	(10, 'http://www.asset1.net/tv/pictures/movie/the-secret-life-of-walter-mitty-2013/The-Secret-Life-Walter-Mitty-03-1.jpg', NULL, 1, NULL),
	(11, 'http://kingofwallpapers.com/hancock/hancock-005.jpg', NULL, 0, NULL),
	(12, 'https://cdn-images-1.medium.com/max/800/0*8oXBkmoqM4i5bgFM.jpg', NULL, -15, NULL),
	(13, 'https://media.senscritique.com/media/000012325142/source_big/Fous_d_Irene.jpg', NULL, 0, NULL),
	(14, 'http://www.france2.fr/emissions/sites/default/files/images/2016/01/02/affiche_film_sda1.jpg', NULL, 0, NULL),
	(15, 'http://fr.web.img3.acsta.net/videothumbnails/16/04/13/16/02/417497.jpg', NULL, 0, NULL),
	(16, 'http://images.commeaucinema.com/galerie/big/4499_7c4ff0641aa687b05a6494822e209472.jpg', NULL, 32, NULL),
	(17, 'http://cdn.collider.com/wp-content/uploads/2016/06/suicide-squad-harley-quinn-poster.jpg', NULL, 0, NULL),
	(18, 'http://static.programme.tv/media/cache/relative_max_355x272/upload/epgs/2015/07/le-roi-lion-3-hakuna-matata_3528562_2.jpg', NULL, 0, NULL),
	(19, 'http://laregledujeu.org/files/2016/04/antonio-banderas-masque-de-zorro.jpg', NULL, 0, NULL),
	(20, 'http://www.contrepoints.org/wp-content/uploads/2015/12/hunger-games.png', NULL, 0, NULL),
	(21, 'http://s2.dmcdn.net/Jx4Bd.jpg', NULL, 0, NULL),
	(22, 'http://openbarmag.fr/wp-content/uploads/2014/12/interstellar-3840x2160.jpg', NULL, -1, NULL),
	(23, 'http://fr.web.img4.acsta.net/c_215_290/medias/nmedia/18/85/31/58/20042068.jpg', NULL, 1, NULL),
	(24, 'http://fr.web.img3.acsta.net/pictures/15/03/18/16/35/340784.jpg', NULL, 2, NULL),
	(25, 'http://www.journaldugeek.com/wp-content/blogs.dir/1/files/2016/06/star-wars-new-hope-honest-trailer.jpg', NULL, 2, NULL),
	(26, 'https://www.wired.com/wp-content/uploads/2016/09/SpockHP-464967684.jpg', NULL, -1, NULL),
	(27, 'http://img.over-blog-kiwi.com/1/21/25/91/20151005/ob_170c4c_the-grinch-how-the-grinch-stole-christ.jpg', NULL, 3, NULL),
	(28, 'http://vignette3.wikia.nocookie.net/slamdunk/images/d/d0/Main.jpg/revision/latest?cb=20140517161021', NULL, 1, NULL),
	(29, 'http://img15.hostingpics.net/pics/224122canalmanga4820.jpg', NULL, 1, NULL),
	(30, 'http://papystreaming.com/fr/files/2014/03/Hajime-no-Ippo.jpg', NULL, 1, NULL),
	(31, 'http://vignette3.wikia.nocookie.net/eyeshield21/images/c/c7/Ch1.jpg/revision/latest?cb=20130521042355', NULL, -12, NULL),
	(32, 'http://fr.web.img6.acsta.net/videothumbnails/16/02/02/18/21/136777.jpg', NULL, 0, NULL),
	(33, 'http://static.mmzstatic.com/wp-content/uploads/2016/07/comme-des-betes-critique3.jpg', NULL, -2, NULL),
	(34, 'https://i.ytimg.com/vi/jc_dSRapCyA/maxresdefault.jpg', NULL, 0, NULL),
	(35, 'https://media.senscritique.com/media/000006511699/source_big/Kuroko_no_basket.jpg', NULL, 0, NULL),
	(36, 'https://pmcvariety.files.wordpress.com/2013/06/vikings1.jpg?w=1000&h=563&crop=1', NULL, -7, 'Vikings'),
	(38, 'http://static.mmzstatic.com/wp-content/uploads/2016/07/the-hound_big_2_.gif', NULL, 41, NULL);
/*!40000 ALTER TABLE `images` ENABLE KEYS */;

-- Export de la structure de la table galleries. ip_score
CREATE TABLE IF NOT EXISTS `ip_score` (
  `ip` varchar(15) NOT NULL,
  `idImage` int(11) NOT NULL,
  `scoreImage` tinyint(4) NOT NULL COMMENT '0 si vote négatif ; 1 si vote positif',
  PRIMARY KEY (`ip`,`idImage`,`scoreImage`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Export de données de la table galleries.ip_score : 20 rows
/*!40000 ALTER TABLE `ip_score` DISABLE KEYS */;
INSERT INTO `ip_score` (`ip`, `idImage`, `scoreImage`) VALUES
	('::1', 2, 0),
	('::1', 4, 1),
	('::1', 5, 1),
	('::1', 10, 1),
	('::1', 16, 1),
	('::1', 22, 0),
	('::1', 24, 1),
	('::1', 25, 1),
	('::1', 26, 0),
	('::1', 27, 1),
	('::1', 28, 1),
	('::1', 29, 1),
	('::1', 30, 1),
	('::1', 31, 1),
	('::1', 32, 0),
	('::1', 33, 0),
	('::1', 34, 0),
	('::1', 35, 1),
	('::1', 36, 0),
	('::1', 38, 1);
/*!40000 ALTER TABLE `ip_score` ENABLE KEYS */;

-- Export de la structure de la table galleries. mainimages_categories
CREATE TABLE IF NOT EXISTS `mainimages_categories` (
  `idMainImage` int(11) NOT NULL,
  `idCategory` int(11) NOT NULL,
  PRIMARY KEY (`idMainImage`,`idCategory`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Export de données de la table galleries.mainimages_categories : 2 rows
/*!40000 ALTER TABLE `mainimages_categories` DISABLE KEYS */;
INSERT INTO `mainimages_categories` (`idMainImage`, `idCategory`) VALUES
	(17, 3),
	(35, 6);
/*!40000 ALTER TABLE `mainimages_categories` ENABLE KEYS */;

-- Export de la structure de la table galleries. parent_child
CREATE TABLE IF NOT EXISTS `parent_child` (
  `idParent` int(11) NOT NULL,
  `idChild` int(11) NOT NULL,
  PRIMARY KEY (`idParent`,`idChild`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Export de données de la table galleries.parent_child : 3 rows
/*!40000 ALTER TABLE `parent_child` DISABLE KEYS */;
INSERT INTO `parent_child` (`idParent`, `idChild`) VALUES
	(1, 6),
	(1, 7),
	(7, 2);
/*!40000 ALTER TABLE `parent_child` ENABLE KEYS */;

-- Export de la structure de la table galleries. settings
CREATE TABLE IF NOT EXISTS `settings` (
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `limitGallery` int(11) NOT NULL,
  `language` varchar(255) COLLATE utf8_bin NOT NULL,
  `idTheme` int(11) NOT NULL,
  KEY `idTheme` (`idTheme`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin MAX_ROWS=1;

-- Export de données de la table galleries.settings : 1 rows
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`title`, `limitGallery`, `language`, `idTheme`) VALUES
	('Gallery', 20, 'French', 1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;

-- Export de la structure de la table galleries. tags
CREATE TABLE IF NOT EXISTS `tags` (
  `idTag` int(11) NOT NULL AUTO_INCREMENT,
  `nameTag` varchar(255) NOT NULL,
  PRIMARY KEY (`idTag`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Export de données de la table galleries.tags : 3 rows
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` (`idTag`, `nameTag`) VALUES
	(1, 'Dessin'),
	(2, 'Panier'),
	(3, 'Nuit');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;

-- Export de la structure de la table galleries. tags_images
CREATE TABLE IF NOT EXISTS `tags_images` (
  `idImage` int(11) NOT NULL,
  `idTag` int(11) NOT NULL,
  PRIMARY KEY (`idImage`,`idTag`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Export de données de la table galleries.tags_images : 4 rows
/*!40000 ALTER TABLE `tags_images` DISABLE KEYS */;
INSERT INTO `tags_images` (`idImage`, `idTag`) VALUES
	(1, 1),
	(2, 2),
	(3, 2),
	(3, 3);
/*!40000 ALTER TABLE `tags_images` ENABLE KEYS */;

-- Export de la structure de la table galleries. themes
CREATE TABLE IF NOT EXISTS `themes` (
  `idTheme` int(11) NOT NULL AUTO_INCREMENT,
  `nameTheme` varchar(255) COLLATE utf8_bin NOT NULL,
  `main_color` varchar(255) COLLATE utf8_bin NOT NULL,
  `body_color` varchar(255) COLLATE utf8_bin NOT NULL,
  `body_font_color` varchar(255) COLLATE utf8_bin NOT NULL,
  `main_dark_font` varchar(255) COLLATE utf8_bin NOT NULL,
  `side_bar_color` varchar(255) COLLATE utf8_bin NOT NULL,
  `side_bar_link_color` varchar(255) COLLATE utf8_bin NOT NULL,
  `side_bar_link_hover_color` varchar(255) COLLATE utf8_bin NOT NULL,
  `side_bar_font_color` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idTheme`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Export de données de la table galleries.themes : 1 rows
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
INSERT INTO `themes` (`idTheme`, `nameTheme`, `main_color`, `body_color`, `body_font_color`, `main_dark_font`, `side_bar_color`, `side_bar_link_color`, `side_bar_link_hover_color`, `side_bar_font_color`) VALUES
	(1, 'Dark Theme', '#fdd700', '#333', '#fff', '#000', '#292b2c', 'rgba(255,255,255,.5)', '#fff', '#dedede');
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
